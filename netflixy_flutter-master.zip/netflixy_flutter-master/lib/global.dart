String getPosterImage(String input){
  return "https://image.tmdb.org/t/p/original/$input";
}